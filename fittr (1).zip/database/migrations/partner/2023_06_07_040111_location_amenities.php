<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('location_amenities', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('location_id')->index('location_id');
            $table->unsignedBigInteger('amenity_id')->index('amenity_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('location_amenities');
    }
};
