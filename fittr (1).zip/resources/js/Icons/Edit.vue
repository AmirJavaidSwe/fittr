<template>
    <svg
        width="18"
        height="19"
        viewBox="0 0 18 19"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
    >
        <path
            d="M10.0504 2.00002L3.20878 9.24168C2.95045 9.51668 2.70045 10.0584 2.65045 10.4334L2.34211 13.1334C2.23378 14.1084 2.93378 14.775 3.90045 14.6084L6.58378 14.15C6.95878 14.0834 7.48378 13.8084 7.74211 13.525L14.5838 6.28335C15.7671 5.03335 16.3004 3.60835 14.4588 1.86668C12.6254 0.141685 11.2338 0.750018 10.0504 2.00002Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-miterlimit="10"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M8.9082 3.20703C9.26654 5.50703 11.1332 7.26536 13.4499 7.4987"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-miterlimit="10"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M1.5 17.332H16.5"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-miterlimit="10"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
    </svg>
</template>
