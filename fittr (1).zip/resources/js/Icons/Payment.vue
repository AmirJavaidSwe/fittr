<template>
<svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M16.3334 7.41333H29.6667" stroke="#315D3F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M19.2934 2.66663H26.7067C29.08 2.66663 29.6667 3.25329 29.6667 5.59996V11.08C29.6667 13.4266 29.08 14.0133 26.7067 14.0133H19.2934C16.92 14.0133 16.3334 13.4266 16.3334 11.08V5.59996C16.3334 3.25329 16.92 2.66663 19.2934 2.66663Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M3.00003 22.7467H16.3334" stroke="#315D3F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M5.96003 18H13.3734C15.7467 18 16.3334 18.5867 16.3334 20.9333V26.4133C16.3334 28.76 15.7467 29.3467 13.3734 29.3467H5.96003C3.5867 29.3467 3.00003 28.76 3.00003 26.4133V20.9333C3.00003 18.5867 3.5867 18 5.96003 18Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M29.6667 20C29.6667 25.16 25.4934 29.3333 20.3334 29.3333L21.7334 27" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M3.00003 12C3.00003 6.83996 7.17336 2.66663 12.3334 2.66663L10.9334 4.99996" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</template>