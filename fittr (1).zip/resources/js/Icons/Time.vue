<template>
    <svg
        width="21"
        height="20"
        viewBox="0 0 21 20"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
    >
        <path
            d="M18.8337 10.0013C18.8337 14.6013 15.1003 18.3346 10.5003 18.3346C5.90033 18.3346 2.16699 14.6013 2.16699 10.0013C2.16699 5.4013 5.90033 1.66797 10.5003 1.66797C15.1003 1.66797 18.8337 5.4013 18.8337 10.0013Z"
            stroke="currentColor"
            stroke-opacity="0.7"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M13.5914 12.6495L11.0081 11.1078C10.5581 10.8411 10.1914 10.1995 10.1914 9.67448V6.25781"
            stroke="currentColor"
            stroke-opacity="0.7"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
    </svg>
</template>
