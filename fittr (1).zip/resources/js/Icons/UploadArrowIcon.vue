<template>
    <svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M16.94 8.90039C20.54 9.21039 22.01 11.0604 22.01 15.1104V15.2404C22.01 19.7104 20.22 21.5004 15.75 21.5004H9.23998C4.76998 21.5004 2.97998 19.7104 2.97998 15.2404V15.1104C2.97998 11.0904 4.42998 9.24039 7.96998 8.91039" stroke="#007AFF" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M12.5 15.0001V3.62012" stroke="#007AFF" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M15.8499 5.85L12.4999 2.5L9.1499 5.85" stroke="#007AFF" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        
</template>