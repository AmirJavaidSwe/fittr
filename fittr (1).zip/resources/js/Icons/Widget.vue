<template>
<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="4" y="4" width="9.33333" height="9.33333" rx="1" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round"/>
    <rect x="4" y="18.6666" width="9.33333" height="9.33333" rx="1" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round"/>
    <rect x="18.6667" y="4" width="9.33333" height="9.33333" rx="1" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round"/>
    <rect x="18.6667" y="18.6666" width="9.33333" height="9.33333" rx="1" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round"/>
</svg>
</template>