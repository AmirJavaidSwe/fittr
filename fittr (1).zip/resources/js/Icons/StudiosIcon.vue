<template>
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 29.3333H20C26.6666 29.3333 29.3333 26.6666 29.3333 20V12C29.3333 5.33329 26.6666 2.66663 20 2.66663H12C5.33329 2.66663 2.66663 5.33329 2.66663 12V20C2.66663 26.6666 5.33329 29.3333 12 29.3333Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M9.77332 19.3201L12.9466 15.2001C13.4 14.6134 14.24 14.5067 14.8266 14.9601L17.2666 16.8801C17.8533 17.3334 18.6933 17.2267 19.1466 16.6534L22.2266 12.6801" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        
</template>