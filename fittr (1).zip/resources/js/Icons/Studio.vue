<template>
<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 29.3334H20C26.6667 29.3334 29.3333 26.6667 29.3333 20V12C29.3333 5.33335 26.6667 2.66669 20 2.66669H12C5.33332 2.66669 2.66666 5.33335 2.66666 12V20C2.66666 26.6667 5.33332 29.3334 12 29.3334Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M16 2.66669V29.3334" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M2.66666 12.6667H16" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M16 19.3333H29.3333" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</template>