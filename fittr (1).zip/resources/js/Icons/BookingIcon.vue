<template>
    <svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M11.0002 2.66663V6.66663" stroke="#315D3F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M21.6667 2.66663V6.66663" stroke="#315D3F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M5.00024 12.12H27.6669" stroke="#315D3F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M24.3336 30.6667C27.2791 30.6667 29.6669 28.2789 29.6669 25.3333C29.6669 22.3878 27.2791 20 24.3336 20C21.3881 20 19.0002 22.3878 19.0002 25.3333C19.0002 28.2789 21.3881 30.6667 24.3336 30.6667Z" stroke="#315D3F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M26.3203 25.4H22.3469" stroke="#315D3F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M24.3335 23.4534V27.44" stroke="#315D3F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M28.3335 11.3333V21.8133C27.3602 20.7066 25.9335 20 24.3335 20C21.3868 20 19.0002 22.3866 19.0002 25.3333C19.0002 26.3333 19.2802 27.28 19.7735 28.08C20.0535 28.56 20.4135 28.9866 20.8268 29.3333H11.0002C6.3335 29.3333 4.3335 26.6666 4.3335 22.6666V11.3333C4.3335 7.33329 6.3335 4.66663 11.0002 4.66663H21.6668C26.3335 4.66663 28.3335 7.33329 28.3335 11.3333Z" stroke="#315D3F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M16.3276 18.2666H16.3395" stroke="#315D3F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M11.3925 18.2666H11.4045" stroke="#315D3F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M11.3925 22.2666H11.4045" stroke="#315D3F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        
</template>
