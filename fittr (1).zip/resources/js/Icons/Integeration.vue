<template>
    <svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M26 21.3333V8.66667C26 7.2 24.8 6 23.3333 6H16" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M19.3333 2.66669L15.3333 6.00002L19.3333 9.33335" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M26 29.3333C28.2091 29.3333 30 27.5425 30 25.3333C30 23.1242 28.2091 21.3333 26 21.3333C23.7908 21.3333 22 23.1242 22 25.3333C22 27.5425 23.7908 29.3333 26 29.3333Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M7.33328 10.6667V23.3334C7.33328 24.8 8.53328 26 9.99995 26H17.3333" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M14 29.3334L18 26L14 22.6667" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M7.33328 10.6667C9.54242 10.6667 11.3333 8.87583 11.3333 6.66669C11.3333 4.45755 9.54242 2.66669 7.33328 2.66669C5.12414 2.66669 3.33328 4.45755 3.33328 6.66669C3.33328 8.87583 5.12414 10.6667 7.33328 10.6667Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
</template>