<template>
<svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M16.3334 29.3333C23.6972 29.3333 29.6667 23.3638 29.6667 16C29.6667 8.63616 23.6972 2.66663 16.3334 2.66663C8.96957 2.66663 3.00003 8.63616 3.00003 16C3.00003 23.3638 8.96957 29.3333 16.3334 29.3333Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M11 4H12.3334C9.73336 11.7867 9.73336 20.2133 12.3334 28H11" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M20.3334 4C22.9334 11.7867 22.9334 20.2133 20.3334 28" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M4.33337 21.3333V20C12.12 22.6 20.5467 22.6 28.3334 20V21.3333" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M4.33337 12C12.12 9.40005 20.5467 9.40005 28.3334 12" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</template>