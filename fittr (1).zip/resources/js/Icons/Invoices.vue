<template>
<svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M29.6667 7.99996V11.2266C29.6667 13.3333 28.3334 14.6666 26.2267 14.6666H21.6667V5.34662C21.6667 3.86662 22.8801 2.66663 24.3601 2.66663C25.8134 2.67996 27.1467 3.26662 28.1067 4.22662C29.0667 5.19996 29.6667 6.53329 29.6667 7.99996Z" stroke="#315D3F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M3.00003 9.33329V28C3.00003 29.1066 4.25336 29.7333 5.13336 29.0666L7.41336 27.36C7.9467 26.96 8.69336 27.0133 9.17336 27.4933L11.3867 29.72C11.9067 30.24 12.76 30.24 13.28 29.72L15.52 27.48C15.9867 27.0133 16.7334 26.96 17.2534 27.36L19.5334 29.0666C20.4134 29.72 21.6667 29.0933 21.6667 28V5.33329C21.6667 3.86663 22.8667 2.66663 24.3334 2.66663H9.6667H8.33336C4.33336 2.66663 3.00003 5.05329 3.00003 7.99996V9.33329Z" stroke="#315D3F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M12.3334 17.3467H16.3334" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M12.3334 12.0133H16.3334" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M8.32751 17.3334H8.33949" stroke="#315D3F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M8.32751 12H8.33949" stroke="#315D3F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</template>