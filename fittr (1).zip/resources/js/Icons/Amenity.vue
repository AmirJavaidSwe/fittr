<template>
<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M4.66667 27.3333C5.77334 28.44 7.56 28.44 8.66667 27.3333L26 9.99998C27.1067 8.89332 27.1067 7.10665 26 5.99998C24.8933 4.89332 23.1067 4.89332 22 5.99998L4.66667 23.3333C3.56 24.44 3.56 26.2266 4.66667 27.3333Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M24.0133 11.9867L20.0133 7.98669" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M11.3333 3.25335L13.3333 2.66669L12.7467 4.66669L13.3333 6.66669L11.3333 6.08002L9.33334 6.66669L9.92001 4.66669L9.33334 2.66669L11.3333 3.25335Z" stroke="#315D3F" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M6 11.2534L8 10.6667L7.41333 12.6667L8 14.6667L6 14.08L4 14.6667L4.58667 12.6667L4 10.6667L6 11.2534Z" stroke="#315D3F" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M26 17.92L28 17.3333L27.4133 19.3333L28 21.3333L26 20.7466L24 21.3333L24.5867 19.3333L24 17.3333L26 17.92Z" stroke="#315D3F" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</template>