<template>
<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M4.01334 14.96V20.9466C4.01334 26.9333 6.41334 29.3333 12.4 29.3333H19.5867C25.5733 29.3333 27.9733 26.9333 27.9733 20.9466V14.96" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M16 16C18.44 16 20.24 14.0133 20 11.5733L19.12 2.66663H12.8933L12 11.5733C11.76 14.0133 13.56 16 16 16Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M24.4133 16C27.1067 16 29.08 13.8133 28.8133 11.1333L28.44 7.46663C27.96 3.99996 26.6267 2.66663 23.1333 2.66663H19.0667L20 12.0133C20.2267 14.2133 22.2133 16 24.4133 16Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M7.52 16C9.72 16 11.7067 14.2133 11.92 12.0133L12.2133 9.06663L12.8533 2.66663H8.78666C5.29333 2.66663 3.96 3.99996 3.48 7.46663L3.12 11.1333C2.85333 13.8133 4.82666 16 7.52 16Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M16 22.6666C13.7733 22.6666 12.6667 23.7733 12.6667 26V29.3333H19.3333V26C19.3333 23.7733 18.2267 22.6666 16 22.6666Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</template>