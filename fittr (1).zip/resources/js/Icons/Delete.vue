<template>
    <svg
        width="20"
        height="20"
        viewBox="0 0 20 20"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
    >
        <path
            d="M17.5 4.98307C14.725 4.70807 11.9333 4.56641 9.15 4.56641C7.5 4.56641 5.85 4.64974 4.2 4.81641L2.5 4.98307"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M7.08301 4.14297L7.26634 3.0513C7.39967 2.25964 7.49967 1.66797 8.90801 1.66797H11.0913C12.4997 1.66797 12.608 2.29297 12.733 3.05964L12.9163 4.14297"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M15.7087 7.61719L15.167 16.0089C15.0753 17.3172 15.0003 18.3339 12.6753 18.3339H7.32533C5.00033 18.3339 4.92533 17.3172 4.83366 16.0089L4.29199 7.61719"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M8.6084 13.75H11.3834"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M7.91699 10.418H12.0837"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
    </svg>
</template>
