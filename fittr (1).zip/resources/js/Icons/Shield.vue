<template>
<svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M14.6534 2.97333L8.00011 5.48C6.46677 6.05333 5.21344 7.86666 5.21344 9.49333V19.4C5.21344 20.9733 6.25344 23.04 7.52011 23.9867L13.2534 28.2667C15.1334 29.68 18.2268 29.68 20.1068 28.2667L25.8401 23.9867C27.1068 23.04 28.1468 20.9733 28.1468 19.4V9.49333C28.1468 7.85333 26.8934 6.04 25.3601 5.46666L18.7068 2.97333C17.5734 2.56 15.7601 2.56 14.6534 2.97333Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12.7334 15.8267L14.8801 17.9733L20.6134 12.24" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</template>