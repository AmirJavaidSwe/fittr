<template>
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M29.3333 22.32V6.22665C29.3333 4.62665 28.0267 3.43999 26.44 3.57332H26.36C23.56 3.81332 19.3067 5.23999 16.9333 6.73332L16.7067 6.87999C16.32 7.11999 15.68 7.11999 15.2933 6.87999L14.96 6.67999C12.5867 5.19999 8.34666 3.78665 5.54666 3.55999C3.95999 3.42665 2.66666 4.62665 2.66666 6.21332V22.32C2.66666 23.6 3.70666 24.8 4.98666 24.96L5.37332 25.0133C8.26666 25.4 12.7333 26.8667 15.2933 28.2667L15.3467 28.2933C15.7067 28.4933 16.28 28.4933 16.6267 28.2933C19.1867 26.88 23.6667 25.4 26.5733 25.0133L27.0133 24.96C28.2933 24.8 29.3333 23.6 29.3333 22.32Z" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M16 7.32001V27.32" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M10.3333 11.32H7.33334" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M11.3333 15.32H7.33334" stroke="#315D3F" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
</template>