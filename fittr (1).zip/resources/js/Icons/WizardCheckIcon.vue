<template>
    <svg width="16" height="12" viewBox="0 0 16 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.32826 9.22878L1.85326 5.75378L0.669922 6.92878L5.32826 11.5871L15.3283 1.58711L14.1533 0.412109L5.32826 9.22878Z" fill="white"/></svg>
</template>