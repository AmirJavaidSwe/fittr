<template>
    <svg
        width="20"
        height="20"
        viewBox="0 0 20 20"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
    >
        <path
            d="M13.6997 7.41602C16.6997 7.67435 17.9247 9.21602 17.9247 12.591V12.6993C17.9247 16.4243 16.4331 17.916 12.7081 17.916H7.28307C3.55807 17.916 2.06641 16.4243 2.06641 12.6993V12.591C2.06641 9.24102 3.27474 7.69935 6.22474 7.42435"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M10 1.66602V12.3993"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M12.7913 10.541L9.99967 13.3327L7.20801 10.541"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
    </svg>
</template>
