<template>
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M19 10C19 10.82 18.88 11.64 18.66 12.4C18.44 13.2 18.12 13.94 17.7 14.64C17.22 15.44 16.62 16.16 15.92 16.76C14.34 18.16 12.28 19 10 19C8.98 19 8.02 18.84 7.12 18.52C5.08 17.84 3.37999 16.44 2.29999 14.64C1.47999 13.28 1 11.68 1 10C1 7.16 2.3 4.61998 4.38 2.97998C5.92 1.73998 7.88 1 10 1C14.98 1 19 5.02 19 10Z" stroke="#42705F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M12.3987 12.3596L7.63867 7.59961" stroke="#42705F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M12.3596 7.64062L7.59961 12.4006" stroke="#42705F" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
</template>