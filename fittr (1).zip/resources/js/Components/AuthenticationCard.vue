// flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100
<template>
            
            <div class="w-full lg:w-1/2 bg-mainBg min-h-screen bg-mainBg">
                <div>
                    <slot name="logo" />
                </div>
                <slot />
            </div>
</template>
