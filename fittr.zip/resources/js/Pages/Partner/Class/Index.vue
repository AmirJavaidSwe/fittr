<script setup>
import { ref, watch, computed } from "vue";
import { Link, useForm, usePage } from "@inertiajs/vue3";
import { DateTime } from "luxon";
import Form from "./Form.vue";
import FormExport from "./FormExport.vue";
import Search from "@/Components/DataTable/Search.vue";
import Pagination from "@/Components/Pagination.vue";
import TableHead from "@/Components/DataTable/TableHead.vue";
import TableData from "@/Components/DataTable/TableData.vue";
import DataTableLayout from "@/Components/DataTable/Layout.vue";
import DialogModal from "@/Components/DialogModal.vue";
import SideModal from "@/Components/SideModal.vue";
import ConfirmationModal from "@/Components/ConfirmationModal.vue";

// import PrimaryButton from '@/Components/PrimaryButton.vue';
import SecondaryButton from "@/Components/SecondaryButton.vue";
import DangerButton from "@/Components/DangerButton.vue";
import WarningButton from "@/Components/WarningButton.vue";
import ButtonLink from "@/Components/ButtonLink.vue";
import { faPlus } from "@fortawesome/free-solid-svg-icons";

const props = defineProps({
    disableSearch: {
        type: Boolean,
        default: false,
    },
    classes: Object,
    search: String,
    per_page: Number,
    order_by: String,
    order_dir: String,

    business_seetings: Object,

    statuses: Object,
    studios: Object,
    instructors: Object,
    classtypes: Object,
});

const form = useForm({
    search: props.search,
    per_page: props.per_page,
    order_by: props.order_by,
    order_dir: props.order_dir,
});

const form_class = useForm({
    title: null,
    status: null,
    start_date: null,
    end_date: null,
    instructor_id: null,
    class_type_id: null,
    studio_id: null,
    file_type: "csv",
    is_off_peak: false,
    does_repeat: false,
    repeat_end_date: null,
    week_days: [],
});

const runSearch = () => {
    form.get(route("partner.classes.index"), {
        preserveScroll: true,
        preserveState: true,
        replace: true,
    });
};

const setPerPage = (n) => {
    form.per_page = n;
    runSearch();
};

// form.search getter only;
watch(() => form.search, runSearch);

//delete confirmation modal:
const itemDeleting = ref(false);
const itemIdDeleting = ref(null);
const confirmDeletion = (id) => {
    itemIdDeleting.value = id;
    itemDeleting.value = true;
};
const deleteItem = () => {
    form.delete(
        route("partner.classes.destroy", { id: itemIdDeleting.value }),
        {
            preserveScroll: true,
            preserveState: true,
            onSuccess: () => {
                itemDeleting.value = false;
                itemIdDeleting.value = null;
            },
        }
    );
};

//create confirmation modal:
const showCreateModal = ref(false);
const closeCreateModal = () => {
    showCreateModal.value = false;
    form_class.reset().clearErrors();
};

const storeClass = () => {
    console.log("storeClass");
    form_class.post(route("partner.classes.store"), {
        preserveScroll: true,
        onSuccess: () => {
            form_class.reset();
            closeCreateModal();
        },
    });
};

//export form modal:
const showExportModal = ref(false);
const exportInitiated = ref(false);
const export_id = ref(null);
const closeExportModal = () => {
    showExportModal.value = false;
};
const resetExportFilters = () => {
    console.log("resetExportFilters");
    form_class.reset();
};

const exportClasses = () => {
    form_class
        .transform((data) => ({
            type: "classes",
            filters: {
                status: data.status,
                start_date: data.start_date,
                end_date: data.end_date,
                instructor_id: data.instructor_id,
                studio_id: data.studio_id,
                is_off_peak: data.is_off_peak,
            },
            file_type: data.file_type,
        }))
        .post(route("partner.exports.index"), {
            preserveScroll: true,
            preserveState: true,
            onSuccess: (data) => {
                form_class.reset();
                exportInitiated.value = true;
                export_id.value = data.props.extra?.export_id;
                checkExportStatus();
            },
        });
};
const completed_at = ref(null);
const checkExportStatus = () => {
    setTimeout(() => {
        // idea is to do quick query here to check for export status. The job may have been complete and we can show a
        // download link inside modal, to avoid visit exports page

        axios
            .get(route("partner.exports.show", { id: export_id.value }), {
                headers: {
                    "X-Inertia": true,
                    "X-Inertia-Version": usePage().version,
                },
            })
            .then((response) => {
                // completed_at.value = null;
                showLink(response.data.props.exporting);
            });
    }, 5000);
};

const showLink = (exporting) => {
    completed_at.value = exporting.completed_at;
};

// show Side Modal
const showSideModal = ref(false);
const closeSideModal = () => {
    showSideModal.value = false;
};
</script>
<template>
    <data-table-layout :disableButton="true">
        <template #button>
            <div class="flex gap-2">
                <SecondaryButton @click="null">
                    <svg class="w-4 h-4 mr-2" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M12.6997 6.41797C15.6997 6.6763 16.9247 8.21797 16.9247 11.593V11.7013C16.9247 15.4263 15.4331 16.918 11.7081 16.918H6.28307C2.55807 16.918 1.06641 15.4263 1.06641 11.7013V11.593C1.06641 8.24297 2.27474 6.7013 5.22474 6.4263" stroke="#949698" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> <path d="M9 11.499V2.01562" stroke="#949698" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> <path d="M11.7913 3.8737L8.99967 1.08203L6.20801 3.8737" stroke="#949698" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    Import
                </SecondaryButton>
                <SecondaryButton @click="showExportModal = true">
                    <svg class="w-4 h-4 mr-2" width="18" height="19" viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M12.6997 7.41797C15.6997 7.6763 16.9247 9.21797 16.9247 12.593V12.7013C16.9247 16.4263 15.4331 17.918 11.7081 17.918H6.28307C2.55807 17.918 1.06641 16.4263 1.06641 12.7013V12.593C1.06641 9.24297 2.27474 7.7013 5.22474 7.4263" stroke="#949698" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> <path d="M9 1.66797V12.4013" stroke="#949698" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> <path d="M11.7913 10.543L8.99967 13.3346L6.20801 10.543" stroke="#949698" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    Export
                </SecondaryButton>
                <!-- <SecondaryButton @click="showCreateModal = true">
                    Create new (modal)
                </SecondaryButton> -->
                <WarningButton @click="showSideModal = true">
                    Create new
                    <font-awesome-icon class="ml-2" :icon="faPlus" />
                </WarningButton>
                <WarningButton
                    :href="route('partner.classes.create')"
                    type="primary"
                >
                    Create new (direct)
                </WarningButton>
            </div>
        </template>

        <template #search>
            <Search
                v-model="form.search"
                :disable-search="disableSearch"
                @reset="form.search = null"
            />
        </template>

        <template #tableHead>
            <table-head title="Id" />
            <table-head title="Title" />
            <table-head title="Studio ID" />
            <table-head title="Instructor ID" />
            <table-head title="Class Type ID" />
            <table-head title="Status" />
            <table-head title="Start" />
            <table-head title="Duration" />
            <table-head title="Updated At" />
            <table-head title="Action" />
        </template>

        <template #tableData>
            <tr v-for="class_lesson in classes.data">
                <table-data :title="class_lesson.id" />
                <table-data>
                    <Link
                        class="font-medium text-indigo-600 hover:text-indigo-500"
                        :href="route('partner.classes.show', class_lesson)"
                    >
                        {{ class_lesson.title }}
                    </Link>
                </table-data>
                <table-data :title="class_lesson.studio_id" />
                <table-data :title="class_lesson.instructor_id" />
                <table-data :title="class_lesson.class_type_id" />
                <table-data>
                    <span
                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full"
                    >
                        {{ class_lesson.status_label }}
                    </span>
                </table-data>
                <table-data
                    :title="
                        DateTime.fromISO(class_lesson.start_date)
                            .setZone(business_seetings.timezone)
                            .toFormat(business_seetings.date_format?.format_js)
                    "
                    :subtitle="
                        DateTime.fromISO(class_lesson.start_date)
                            .setZone(business_seetings.timezone)
                            .toFormat(business_seetings.time_format?.format_js)
                    "
                >
                </table-data>

                <table-data :title="class_lesson.duration" />
                <table-data
                    :title="
                        DateTime.fromISO(class_lesson.updated_at).toRelative()
                    "
                />
                <table-data>
                    <Link
                        class="font-medium text-indigo-600 hover:text-indigo-500"
                        :href="route('partner.classes.edit', class_lesson)"
                    >
                        Edit
                    </Link>
                    <br />
                    <button
                        class="block text-red-500"
                        @click="confirmDeletion(class_lesson.id)"
                    >
                        Delete
                    </button>
                </table-data>
            </tr>
        </template>

        <template #pagination>
            <pagination :links="classes.links" :to="classes.to" :from="classes.from" :total="classes.total" @pp_changed="setPerPage" />
        </template>
    </data-table-layout>

    <!-- Export form Modal -->
    <DialogModal :show="showExportModal" @close="closeExportModal">
        <template #title> Export Classes </template>

        <template #content>
            <FormExport
                :form="form_class"
                :initiated="exportInitiated"
                :ready="completed_at"
                :statuses="statuses"
                :studios="studios"
                :instructors="instructors"
                @submitted="exportClasses"
                @reset="resetExportFilters"
            />
        </template>
    </DialogModal>

    <!-- Create new class Modal -->
    <DialogModal :show="showCreateModal" @close="closeCreateModal">
        <template #title> Create new Class </template>

        <template #content>
            <Form
                :form="form_class"
                :isNew="true"
                :statuses="statuses"
                :studios="studios"
                :instructors="instructors"
                :classtypes="classtypes"
                :business_seetings="business_seetings"
                :submitted="storeClass"
            />
        </template>
    </DialogModal>

    <!-- Delete Confirmation Modal -->
    <ConfirmationModal :show="itemDeleting" @close="itemDeleting = false">
        <template #title> Confirmation required </template>

        <template #content>
            Are you sure you would like to delete this?
        </template>

        <template #footer>
            <SecondaryButton @click="itemDeleting = null">
                Cancel
            </SecondaryButton>

            <DangerButton
                class="ml-3"
                :class="{ 'opacity-25': form.processing }"
                :disabled="form.processing"
                @click="deleteItem"
            >
                Delete
            </DangerButton>
        </template>
    </ConfirmationModal>

    <SideModal :show="showSideModal" @close="closeSideModal">
        <template #title> Create New Class </template>
        <template #content>
            <Form
                :form="form_class"
                :isNew="true"
                :statuses="statuses"
                :studios="studios"
                :instructors="instructors"
                :classtypes="classtypes"
                :business_seetings="business_seetings"
                :submitted="storeClass"
            />
        </template>
    </SideModal>
</template>
