<script setup>
import Welcome from '@/Components/Welcome.vue';
</script>

<template>
    <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
        <Welcome />
    </div>
</template>
