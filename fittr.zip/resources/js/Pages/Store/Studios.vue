<script setup>
import Section from '@/Components/Section.vue';
import ButtonLink from '@/Components/ButtonLink.vue';
const props = defineProps({
    studios: {
        type: Object,
        required: true,
    },
});
</script>

<template>
    <Section bg="bg-transparent">
        <div class="text-xl mb-4">
            Our Facilities
        </div>
        <div class="flex flex-wrap gap-4 flex-1">
            <div v-for="item in studios" :key="item.id" class="bg-white p-4 rounded shadow-md flex-grow">
                <div class="font-bold mb-2">{{item.title}}</div>
                <div>desc: {{item.brief}}</div>
                <div>address_line_1: {{item.address_line_1}}</div>
                <div>address_line_2: {{item.address_line_2}}</div>
                <div>city: {{item.city}}</div>
                <div>postcode: {{item.postcode}}</div>
                <div>phone: {{item.tel}}</div>

                <div v-if="item.amenities.length" class="font-bold mb-2">Amenities</div>
                <div v-for="amenity in item.amenities" :key="amenity.id" class="bg-gray-50 p-1">
                    <div class="font-semibold mb-1 text-lg">{{amenity.title}}</div>
                    <div>{{amenity.contents}}</div>
                </div>
            </div>
        </div>

    </Section>
</template>
