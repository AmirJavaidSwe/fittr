import './bootstrap';
import '../css/app.css';

import { createApp, h } from 'vue';
import { createInertiaApp } from '@inertiajs/vue3';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';
import { ZiggyVue } from '../../vendor/tightenco/ziggy/dist/vue.m';
import AppLayout from './Layouts/AppLayout.vue';
import StoreLayout from './Layouts/StoreLayout.vue';
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome';
import directive from './directive';

const appName = window.document.getElementsByTagName('title')[0]?.innerText || 'Laravel';

createInertiaApp({
    title: (title) => `${title} - ${appName}`,
    resolve: (name) => {
        const page = resolvePageComponent(`./Pages/${name}.vue`, import.meta.glob('./Pages/**/*.vue'));
        page.then((module) => {
            switch (true) {
                // service store layout
                case name.startsWith('Store/'):
                    module.default.layout = StoreLayout;
                    break;

                // admin and partners
                case name != 'Welcome' && !name.startsWith('Auth/'):
                    module.default.layout = AppLayout;
                    break;

                // below pages don't use layout
                default:
                    console.log('default');
                    break;
            }
        });
        return page;
    },
    progress: {
        delay: 500,
        color: '#4B5563',
        includeCSS: true,
        showSpinner: false,
    },
    setup({ el, App, props, plugin }) {
        const app = createApp({ render: () => h(App, props) });

        app.use(plugin);
        app.use(ZiggyVue, Ziggy);
        app.component('font-awesome-icon', FontAwesomeIcon);
        app.use(directive); // Register the custom directive here

        return app.mount(el);
    },
});
