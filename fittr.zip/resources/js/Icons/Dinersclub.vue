<template>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 26 24">
        <g fill="none" fill-rule="evenodd">
            <g fill-rule="nonzero">
                <path fill="#2283CB" d="M14.62 22.98H10.7A10.9 10.9 0 0 1 0 12.08C-.18 6.16 4.4 1.2 10.24 1h4.4A11.09 11.09 0 0 1 25.8 12v.1a11.2 11.2 0 0 1-11.18 10.89z"></path>
                <path fill="#FFF" d="M11 2.91A9.13 9.13 0 0 0 1.91 12c0 4.97 4.1 9.07 9.07 9.07 4.97 0 9.08-4.1 9.08-9.07 0-4.97-4.11-9.08-9.08-9.08z"></path>
                <path fill="#2283CB" d="M12.42 18.1V5.97a6.24 6.24 0 0 1 0 12.13zm-2.86 0a6.28 6.28 0 0 1 0-12.13V18.1z"></path>
            </g>
            <path d="M0 0h26v24H0z"></path>
        </g>
    </svg>
</template>