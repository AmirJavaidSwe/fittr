<script setup>
import { ref, computed, defineAsyncComponent } from "vue";
import { router, Link, usePage } from "@inertiajs/vue3";
import AppHead from "@/Layouts/AppHead.vue";
import LogoLetter from "@/Components/LogoLetter.vue";
import Banner from "@/Components/Banner.vue";
import FlashMessage from "@/Components/FlashMessage.vue";
import Dropdown from "@/Components/Dropdown.vue";
import DropdownLink from "@/Components/DropdownLink.vue";
import NavLink from "@/Components/NavLink.vue";
import ResponsiveNavLink from "@/Components/ResponsiveNavLink.vue";
import { faBars, faBell, faComment, faHeart } from "@fortawesome/free-solid-svg-icons";

const showingNavigationDropdown = ref(false);

const switchToTeam = (team) => {
    router.put(
        route("current-team.update"),
        {
            team_id: team.id,
        },
        {
            preserveState: false,
        }
    );
};

const logout = () => {
    router.post(route("logout"));
};

const toggleMenu = (v) => {
    showingNavigationDropdown.value = v;
};

const MainMenu = defineAsyncComponent(() => {
    const is_partner = usePage().props.user.is_partner;
    return is_partner ? import("./PartnerMenu.vue") : import("./AdminMenu.vue");
});

const header = computed(() => {
    return usePage().props.header;
});
const headerIsArray = computed(() => {
    return Array.isArray(header.value);
});

// Sidebar Collapse
const sidebarCollapsed = ref(true);
</script>

<template>
    <div>
        <AppHead :title="$page.props.page_title">
            <Link
                rel="apple-touch-icon"
                sizes="180x180"
                href="/apple-touch-icon.png"
            />
            <Link
                rel="icon"
                type="image/png"
                sizes="32x32"
                href="/favicon-32x32.png"
            />
            <Link
                rel="icon"
                type="image/png"
                sizes="16x16"
                href="/favicon-16x16.png"
            />
            <Link rel="manifest" href="/site.webmanifest" />
        </AppHead>

        <Banner />
        <FlashMessage :flash="$page.props.flash" :errors="$page.props.errors" />

        <div class="min-h-screen bg-gray-50 overflow-hidden">
            <!-- Desktop, flex -->
            <div class="md:h-screen">
                <div class="md:flex md:h-full">
                    {{ console.log(sidebarCollapsed) }}
                    <!-- Sidebar -->
                    <div :class="sidebarCollapsed ? 'md:flex md:flex-col md:w-0 transition-all duration-300' : 'md:flex md:flex-col md:w-56 transition-all duration-300'">
                        <div class="md:w-56 h-full bg-primary">
                            <div
                            class="flex items-center px-6 py-4 md:flex-shrink-0"
                        >
                            <!-- Logo -->
                            <Link
                                :href="route($page.props.user.dashboard_route)"
                                class="mt-1"
                            >
                                <LogoLetter class="w-32 h-12" fill="#fff" />
                            </Link>

                            <!-- Mobile toggle, visible md and smaller -->
                            <Dropdown
                                align="right"
                                width="48"
                                :content-classes="['bg-gray-100', 'p-1']"
                                @toggled="toggleMenu"
                            >
                                <template #trigger>
                                    <button
                                        class="md:hidden inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 focus:text-gray-500 transition"
                                    >
                                        <svg
                                            class="h-6 w-6"
                                            stroke="currentColor"
                                            fill="none"
                                            viewBox="0 0 24 24"
                                        >
                                            <path
                                                :class="{
                                                    hidden: showingNavigationDropdown,
                                                    'inline-flex':
                                                        !showingNavigationDropdown,
                                                }"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                stroke-width="2"
                                                d="M4 6h16M4 12h16M4 18h16"
                                            />
                                            <path
                                                :class="{
                                                    hidden: !showingNavigationDropdown,
                                                    'inline-flex':
                                                        showingNavigationDropdown,
                                                }"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                stroke-width="2"
                                                d="M6 18L18 6M6 6l12 12"
                                            />
                                        </svg>
                                    </button>
                                </template>
                                <template #content>
                                    <MainMenu class="hidden:md" />
                                </template>
                            </Dropdown>
                        </div>

                        <!-- Menu -->
                        <MainMenu class="hidden md:block" />
                        </div>
                    </div>

                    <!-- Main Content -->
                    <div
                        class="md:flex md:flex-col md:flex-1 md:overflow-hidden"
                    >
                        <div
                            class="bg-white flex items-center justify-between md:px-6 md:py-0 md:text-md p-4 shadow text-sm w-full gap-4 relative"
                        >
                            <!-- Page Heading / Menu item name-->
                            <header>
                                <div class="flex items-center">
                                    <button type="type" class="border-0 p-0 bg-transparent" @click="sidebarCollapsed = !sidebarCollapsed">
                                        <font-awesome-icon :icon="faBars" class="mr-3 w-6 h-6" />
                                    </button>
                                    <div
                                        class="max-w-7xl mx-auto py-6"
                                    >
                                        <h2
                                            class="font-semibold text-xl text-gray-800 leading-tight"
                                        >
                                            <div
                                                v-if="headerIsArray"
                                                class="flex flex-wrap gap-2"
                                            >
                                                <div v-for="item in header">
                                                    <Link
                                                        v-if="item.link"
                                                        :href="item.link"
                                                        class="text-blue-600"
                                                        >{{ item.title }}</Link
                                                    >
                                                    <span v-else>
                                                        {{ item.title }}
                                                    </span>
                                                </div>
                                            </div>
                                            <span v-else>{{ header }}</span>
                                        </h2>
                                    </div>
                                </div>
                            </header>

                            <div class="flex items-center">
                                <!-- Setting Links -->

                                <ul class="flex gap-5 pe-6 py-2 border-r-2 border-gray-200">
                                    <li>
                                        <a href="#"><svg class="w-5 h-5" width="18" height="21" viewBox="0 0 18 21" fill="none" xmlns="http://www.w3.org/2000/svg" > <path d="M9.0196 0.910156C5.7096 0.910156 3.0196 3.60016 3.0196 6.91016V9.80016C3.0196 10.4102 2.7596 11.3402 2.4496 11.8602L1.2996 13.7702C0.5896 14.9502 1.0796 16.2602 2.3796 16.7002C6.6896 18.1402 11.3396 18.1402 15.6496 16.7002C16.8596 16.3002 17.3896 14.8702 16.7296 13.7702L15.5796 11.8602C15.2796 11.3402 15.0196 10.4102 15.0196 9.80016V6.91016C15.0196 3.61016 12.3196 0.910156 9.0196 0.910156Z" stroke="#292D32" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" /> <path d="M12.0195 17.0586C12.0195 18.7086 10.6695 20.0586 9.01953 20.0586C8.19953 20.0586 7.43953 19.7186 6.89953 19.1786C6.35953 18.6386 6.01953 17.8786 6.01953 17.0586" stroke="#292D32" stroke-width="1.5" stroke-miterlimit="10" /></svg>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#"><svg class="w-5 h-5" width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg" > <path d="M7.5 18H7C3 18 1 17 1 12V7C1 3 3 1 7 1H15C19 1 21 3 21 7V12C21 16 19 18 15 18H14.5C14.19 18 13.89 18.15 13.7 18.4L12.2 20.4C11.54 21.28 10.46 21.28 9.8 20.4L8.3 18.4C8.14 18.18 7.77 18 7.5 18Z" stroke="#292D32" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round" /> <path d="M6 7H16" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" /> <path d="M6 12H12" stroke="#292D32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" /></svg>
                                        </a>
                                    </li>
                                </ul>

                                <!-- Settings Dropdown -->
                                <div class="relative flex-shrink-0">
                                    <Dropdown
                                        align="right"
                                        width="48"
                                        :content-classes="['bg-white']"
                                    >
                                        <template #trigger>
                                            <div
                                                v-if="
                                                    $page.props.jetstream
                                                        .managesProfilePhotos
                                                "
                                                class="flex items-center justify-center"
                                            >
                                                <div class="px-4 text-right">
                                                    <div class="font-bold">
                                                        {{
                                                            $page.props.user
                                                                .name
                                                        }}
                                                    </div>
                                                    <div class="text-gray-400">
                                                        {{
                                                            $page.props.user
                                                                .email
                                                        }}
                                                    </div>
                                                </div>
                                                <button
                                                    class="flex text-sm border-2 border-gray-100 rounded-full focus:outline-none focus:border-gray-300 transition"
                                                >
                                                    <img
                                                        class="h-10 w-10 rounded-full object-cover"
                                                        :src="
                                                            $page.props.user
                                                                .profile_photo_url
                                                        "
                                                        :alt="
                                                            $page.props.user
                                                                .name
                                                        "
                                                    />
                                                </button>
                                            </div>

                                            <span
                                                v-else
                                                class="inline-flex rounded-md"
                                            >
                                                <button
                                                    type="button"
                                                    class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition"
                                                >
                                                    {{ $page.props.user.name }}

                                                    <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" > <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" /> </svg>
                                                </button>
                                            </span>
                                        </template>

                                        <template #content>
                                            <!-- Account Management -->

                                            <DropdownLink
                                                :href="route('profile.show')"
                                            >
                                                Profile
                                            </DropdownLink>

                                            <!-- <DropdownLink v-if="$page.props.jetstream.hasApiFeatures" :href="route('api-tokens.index')">
                                            API Tokens
                                        </DropdownLink> -->

                                            <DropdownLink
                                                v-if="
                                                    $page.props.user.is_partner
                                                "
                                                :href="
                                                    route(
                                                        'partner.subscriptions.index'
                                                    )
                                                "
                                            >
                                                Billing
                                            </DropdownLink>

                                            <DropdownLink
                                                v-if="
                                                    $page.props.user.is_partner
                                                "
                                                :href="
                                                    route(
                                                        'partner.contact.index'
                                                    )
                                                "
                                            >
                                                Contact support
                                            </DropdownLink>

                                            <div
                                                class="border-t border-gray-100"
                                            />

                                            <!-- Authentication -->
                                            <form @submit.prevent="logout">
                                                <DropdownLink as="button">
                                                    Log Out
                                                </DropdownLink>
                                            </form>
                                        </template>
                                    </Dropdown>
                                </div>
                            </div>
                        </div>
                        <!-- Page Content -->
                        <div class="md:flex-1 overflow-y-auto bg-mainBg">
                            <main class="py-8 px-4 sm:px-6">
                                <slot />
                            </main>
                        </div>
                        <!-- footer -->
                        <footer
                            class="bg-gray-100 h-applayout_footer flex items-center justify-center text-center text-gray-400 text-xs"
                        >
                            MADE WITH
                            <font-awesome-icon :icon="faHeart" class="mx-2" />
                            IN LONDON
                        </footer>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
