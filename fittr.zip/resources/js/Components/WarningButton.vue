<script setup>
import { Link } from '@inertiajs/vue3';

defineProps({
    href: String,
    type: {
        type: String,
        default: 'button',
    },
});
</script>

<template>
    <template v-if="href">
        <Link :href="href" class="inline-flex items-center justify-center px-4 py-3 bg-amber-500 rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-amber-600 focus:outline-none focus:border-amber-600 focus:ring focus:ring-ramber-600 active:bg-amber-600 disabled:opacity-25 transition"><slot /></Link>
    </template>
    <template v-else>
        <button :type="type" class="inline-flex items-center justify-center px-4 py-3 bg-amber-500 rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-amber-600 focus:outline-none focus:border-amber-600 focus:ring focus:ring-ramber-600 active:bg-amber-600 disabled:opacity-25 transition">
            <slot />
        </button>
    </template>
</template>
